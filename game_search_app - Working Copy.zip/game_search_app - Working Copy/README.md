# game_search_app

Game Search App

A Flutter web/desktop/mobile application powered by Supabase and Hive for offline caching. Search, filter, and browse video games without losing your data when offline.

Features

Live Search: Debounced input (300ms) to avoid excessive requests.

Supabase Integration: Fetches from a Supabase games table.

Filters:

Platform (e.g. Steam, PC, Xbox, etc.)

Genre (e.g. Action, RPG, Strategy, etc.)

Release Date range

Developer and Publisher filters

Offline Caching: Uses Hive to store last-fetched results.

Automatic Sync: Cached data is updated whenever a new query runs online.

Prerequisites

Flutter SDK (>=3.0)

Dart SDK

Supabase project with a games table, containing columns:

id (uuid or serial primary key)

title (text)

platform (text)

genre (text or text[])

release_date (date)

developer (text)

publisher (text)

Setup

Clone the repo:

git clone https://github.com/yourusername/game_search_app.git
cd game_search_app

Install dependencies:

flutter pub get

Configure Supabase:

In lib/main.dart, replace your URL and anon key:

await Supabase.initialize(
  url: 'https://YOUR-PROJECT.supabase.co',
  anonKey: 'YOUR-ANON-KEY',
);

Run the app:

flutter run

Usage

Search: Start typing in the search bar; results load after 300 ms of inactivity.

Filter: Use dropdowns for Platform, Genre, Developer, Publisher, and pick a date range.

Offline: When offline, you’ll see cached results; once back online, filters/search will refresh.

Extending

Add more filters: In search_page.dart, update the query builder to include additional .eq() or .ilike() calls.

Improve UI: Style with Flutter theming or add custom cards for each game.

Persist settings: Use Hive to store last-used filters.

Troubleshooting

Blank Screen: Ensure your Supabase keys are correct and your table has data.

Type Errors: Run flutter pub upgrade supabase_flutter to match package versions.

Offline Caching: Confirm Hive box opens without errors (await Hive.openBox('gamesBox')).

Enjoy browsing your game collection on any device—online or off! Feel free to contribute via pull requests.")

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
