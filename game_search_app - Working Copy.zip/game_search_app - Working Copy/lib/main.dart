// lib/main.dart

import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'search_page.dart';  // ← your UI page

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1️⃣ Initialize Hive
  await Hive.initFlutter();
  await Hive.openBox('gamesBox');

  // 2️⃣ Initialize Supabase
  await Supabase.initialize(
    url: 'https://mbdrtvxcjijgzxlzlfzw.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1iZHJ0dnhjamlqZ3p4bHpsZnp3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUxNjQ2NzYsImV4cCI6MjA2MDc0MDY3Nn0.8phlukCcNjY0QQ5LDsl4KFnawuUoXwHCR2OuxLrLZVQ',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);  // super.key style

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Game Search',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const SearchPage(),  // ← no query logic here
    );
  }
}
