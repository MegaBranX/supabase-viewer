import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _client = Supabase.instance.client;
  final _box    = Hive.box('gamesBox');

  List<Map<String, dynamic>> _games      = [];
  bool                      _loading    = false;
  Timer?                    _debounce;
  String                    _lastSearch = '';

  // filters
  final _platforms = ['All','Steam','PC','Console'];
  String _plat = 'All';
  final _genres    = ['All','Action','RPG','Adventure','Puzzle'];
  String _genre = 'All';

  @override
  void initState() {
    super.initState();
    // load + normalize cache
    final cached = _box.get('games') as List<dynamic>?;
    if (cached != null) {
      _games = cached
        .map((e) => Map<String,dynamic>.from(e as Map))
        .toList();
    }
    _searchGames(''); // initial load
  }

  @override
  void dispose() {
    _debounce?.cancel();
    Hive.close();
    super.dispose();
  }

  void _onSearchChanged(String txt) {
    _lastSearch = txt;
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds:300), () {
      _searchGames(txt);
    });
  }

  Future<void> _searchGames(String txt) async {
    setState(() => _loading = true);
    try {
      var qb = _client
        .from('games')
        // explicitly pick only the fields you need
        .select<List<Map<String,dynamic>>>('''
          title,
          platform,
          genre,
          release_date,
          developer,
          publisher
        ''')
        .ilike('title', '%$txt%');

      if (_plat!='All') {
        qb = qb.eq('platform', _plat);
      }
      if (_genre!='All') {
        qb = qb.contains('genre', [_genre]);
      }

      final data = await qb.order('title', ascending:true);
      setState(() => _games = data);
      _box.put('games', data); // cache
    } catch(e) {
      debugPrint('Error fetching games: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Search Games')),
    body: Column(
      children: [
        // Filters
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _plat,
                decoration: const InputDecoration(
                  labelText: 'Platform',
                  border: OutlineInputBorder(),
                ),
                items: _platforms
                  .map((p) => DropdownMenuItem(value:p,child:Text(p)))
                  .toList(),
                onChanged: (v){
                  if (v == null) return;
                  setState(() => _plat = v);
                  _searchGames(_lastSearch);
                },
              ),
            ),
            const SizedBox(width:8),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _genre,
                decoration: const InputDecoration(
                  labelText: 'Genre',
                  border: OutlineInputBorder(),
                ),
                items: _genres
                  .map((g) => DropdownMenuItem(value:g,child:Text(g)))
                  .toList(),
                onChanged: (v){
                  if (v == null) return;
                  setState(() => _genre = v);
                  _searchGames(_lastSearch);
                },
              ),
            ),
          ]),
        ),

        // Search box
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Search by title…',
              border: OutlineInputBorder(),
            ),
            onChanged: _onSearchChanged,
          ),
        ),

        if (_loading) const LinearProgressIndicator(),

        // Results
        Expanded(
          child: ListView.builder(
            itemCount: _games.length,
            itemBuilder: (_, i) {
              final g = _games[i];
              return ListTile(
                title: Text(g['title'] ?? ''),
                isThreeLine: true,
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${g['platform']} • ${g['genre']}'),
                    Text('Dev: ${g['developer']} • Pub: ${g['publisher']}'),
                    Text('Released: ${g['release_date']}'),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}
